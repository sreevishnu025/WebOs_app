import React from "react";

function Percentage() {
  return (
    <div className="percentage">
      {" "}
      93%
      <i class="fa fa-battery-full" aria-hidden="true"></i>
    </div>
  );
}

export default Percentage;
